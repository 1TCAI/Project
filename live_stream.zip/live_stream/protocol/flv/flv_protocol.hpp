/*
MIT License

Copyright (c) 2021 jiangbaolin

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.
*/
#pragma once
#include <arpa/inet.h>
#include <string.h>
#include <vector>
#include <memory>
#include <list>

#include "server/rtmp/rtmp_protocol/rtmp_define.hpp"

namespace mms {
#define FLV_IDENTIFIER  "FLV"

class RtmpMessage;
struct FlvHeader {
    uint8_t signature[3];
    uint8_t version = 0x01;
    using Flags = struct {
        uint8_t reserved1:5 = 0;
        uint8_t audio:1 = 0;
        uint8_t reserved2:1 = 0;
        uint8_t video:1 = 0;
    };
    Flags flag;
    uint32_t data_offset = 0x09;

    static int32_t encode(uint8_t *data, size_t len);
    int32_t decode(uint8_t *data, size_t len);
};

struct FlvTagHeader {
    enum TagType : uint8_t {
        AudioTag    = 8,
        VideoTag    = 9,
        ScriptTag   = 18,
    };

    uint8_t tag_type;
    uint32_t data_size = 0;//3byte
    uint32_t timestamp;//4byte
    uint32_t stream_id;//3byte

    static int32_t encodeFromRtmpMessage(std::shared_ptr<RtmpMessage> msg, uint8_t *data, size_t len);
    int32_t encode(uint8_t *data, size_t len);
    int32_t decode(const uint8_t *data, size_t len);
};

};