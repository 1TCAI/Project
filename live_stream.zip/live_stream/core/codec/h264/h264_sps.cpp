#include "h264_sps.hpp"
#include "base/utils/bit_stream.hpp"
using namespace mms;
#define Extended_SAR 0xff
bool vui_parameters_t::parse(BitStream & bit_stream) {
    if (!bit_stream.read_one_bit(aspect_ratio_info_present_flag)) {
        return false;
    }

    if (aspect_ratio_info_present_flag) {
        if (!bit_stream.read_bits(8, aspect_ratio_idc)) {
            return false;
        }

        if (aspect_ratio_idc == Extended_SAR) {
            if (!bit_stream.read_bits(16, sar_width)) {
                return false;
            }

            if (!bit_stream.read_bits(16, sar_height)) {
                return false;
            }
        }
    }

    if (!bit_stream.read_one_bit(overscan_info_present_flag)) {
        return false;
    }

    if (overscan_info_present_flag) {
        if (!bit_stream.read_one_bit(overscan_appropriate_flag)) {
            return false;
        }
    }

    if (!bit_stream.read_one_bit(video_signal_type_present_flag)) {
        return false;
    }

    if (video_signal_type_present_flag) {
        if (!bit_stream.read_bits(3, video_format)) {
            return false;
        }

        if (!bit_stream.read_one_bit(video_full_range_flag)) {
            return false;
        }

        if (!bit_stream.read_one_bit(colour_description_present_flag)) {
            return false;
        }

        if (colour_description_present_flag) {
            if (!bit_stream.read_bits(8, colour_primaries)) {
                return false;
            }

            if (!bit_stream.read_bits(8, transfer_characteristics)) {
                return false;
            }

            if (!bit_stream.read_bits(8, matrix_coefficients)) {
                return false;
            }
        }
    }

    if (!bit_stream.read_one_bit(chroma_loc_info_present_flag)) {
        return false;
    }

    if (chroma_loc_info_present_flag) {
        if (!bit_stream.read_exp_golomb_ue(chroma_sample_loc_type_top_field)) {
            return false;
        }

        if (!bit_stream.read_exp_golomb_ue(chroma_sample_loc_type_bottom_field)) {
            return false;
        }
    }

    if (!bit_stream.read_one_bit(timing_info_present_flag)) {
        return false;
    }

    if (timing_info_present_flag) {
        if (!bit_stream.read_bits(32, num_units_in_tick)) {
            return false;
        }

        if (!bit_stream.read_bits(32, time_scale)) {
            return false;
        }

        if (!bit_stream.read_one_bit(fixed_frame_rate_flag)) {
            return false;
        }
    }

    if (!bit_stream.read_one_bit(nal_hrd_parameters_present_flag)) {
        return false;
    }

    if (nal_hrd_parameters_present_flag) {
        if (!hrd_parameters1.parse(bit_stream)) {
            return false;
        }
    }

    if (!bit_stream.read_one_bit(vcl_hrd_parameters_present_flag)) {
        return false;
    }

    if (vcl_hrd_parameters_present_flag) {
        if (!hrd_parameters2.parse(bit_stream)) {
            return false;
        }
    }

    if (nal_hrd_parameters_present_flag || vcl_hrd_parameters_present_flag) {
        if (!bit_stream.read_one_bit(low_delay_hrd_flag)) {
            return false;
        }
    }

    if (!bit_stream.read_one_bit(pic_struct_present_flag)) {
        return false;
    }

    if (!bit_stream.read_one_bit(bitstream_restriction_flag)) {
        return false;
    }

    if (bitstream_restriction_flag) {
        if (!bit_stream.read_one_bit(motion_vectors_over_pic_boundaries_flag)) {
            return false;
        }

        if (!bit_stream.read_exp_golomb_ue(max_bytes_per_pic_denom)) {
            return false;
        }

        if (!bit_stream.read_exp_golomb_ue(max_bits_per_mb_denom)) {
            return false;
        }

        if (!bit_stream.read_exp_golomb_ue(log2_max_mv_length_horizontal)) {
            return false;
        }

        if (!bit_stream.read_exp_golomb_ue(log2_max_mv_length_vertical)) {
            return false;
        }

        if (!bit_stream.read_exp_golomb_ue(max_num_reorder_frames)) {
            return false;
        }

        if (!bit_stream.read_exp_golomb_ue(max_dec_frame_buffering)) {
            return false;
        }
    }

    return true;
}

bool hrd_parameters_t::parse(BitStream & bit_stream) {
    if (!bit_stream.read_exp_golomb_ue(cpb_cnt_minus1)) {
        return false;
    }

    if (!bit_stream.read_bits(4, bit_rate_scale)) {
        return false;
    }

    if (!bit_stream.read_bits(4, cpb_size_scale)) {
        return false;
    }

    for (uint64_t SchedSelIdx = 0; SchedSelIdx <= cpb_cnt_minus1; SchedSelIdx++) {
        uint64_t v;
        if (!bit_stream.read_exp_golomb_ue(v)) {
            return false;
        }
        bit_rate_value_minus1.push_back(v);

        if (!bit_stream.read_exp_golomb_ue(v)) {
            return false;
        }
        cpb_size_value_minus1.push_back(v);

        uint8_t b;
        if (!bit_stream.read_one_bit(b)) {
            return false;
        }
        cbr_flag.push_back(b);
    }

    if (!bit_stream.read_bits(5, initial_cpb_removal_delay_length_minus1)) {
        return false;
    }

    if (!bit_stream.read_bits(5, cpb_removal_delay_length_minus1)) {
        return false;
    }

    if (!bit_stream.read_bits(5, dpb_output_delay_length_minus1)) {
        return false;
    }

    if (!bit_stream.read_bits(5, time_offset_length)) {
        return false;
    }
    return true;
}

bool h264_sps_t::parse(BitStream & bit_stream) { 
    if (!bit_stream.read_bits(8, profile_idc)) {
        return false;
    }

    if (!bit_stream.read_one_bit(constraint_set0_flag)) {
        return false;
    }

    if (!bit_stream.read_one_bit(constraint_set1_flag)) {
        return false;
    }

    if (!bit_stream.read_one_bit(constraint_set2_flag)) {
        return false;
    }

    if (!bit_stream.read_one_bit(constraint_set3_flag)) {
        return false;
    }

    if (!bit_stream.read_one_bit(constraint_set4_flag)) {
        return false;
    }

    if (!bit_stream.read_one_bit(constraint_set5_flag)) {
        return false;
    }

    if (!bit_stream.read_bits(2, reserved_zero_2bits)) {
        return false;
    }

    if (!bit_stream.read_bits(8, level_idc)) {
        return false;
    }

    if (!bit_stream.read_exp_golomb_ue(seq_parameter_set_id)) {
        return false;
    }

    if( profile_idc == 100 || profile_idc == 110 ||
        profile_idc == 122 || profile_idc == 244 || profile_idc == 44 ||
        profile_idc == 83 || profile_idc == 86 || profile_idc == 118 ||
        profile_idc == 128 || profile_idc == 138 || profile_idc == 139 ||
        profile_idc == 134 || profile_idc == 135 ) {
        if (!bit_stream.read_exp_golomb_ue(chroma_format_idc)) {
            return false;
        }

        if (chroma_format_idc == 3) {
            if (!bit_stream.read_one_bit(separate_colour_plane_flag)) {
                return false;
            }
        }

        if (!bit_stream.read_exp_golomb_ue(bit_depth_luma_minus8)) {
            return false;
        }

        if (!bit_stream.read_exp_golomb_ue(bit_depth_chroma_minus8)) {
            return false;
        }

        if (!bit_stream.read_one_bit(qpprime_y_zero_transform_bypass_flag)) {
            return false;
        }

        if (!bit_stream.read_one_bit(seq_scaling_matrix_present_flag)) {
            return false;
        }

        if (seq_scaling_matrix_present_flag) {
            uint64_t len;
            if (chroma_format_idc != 3) {
                len = 8;
            } else {
                len = 12;
            }

            for (uint64_t i = 0; i < len; i++) {
                uint8_t b = 0;
                if (!bit_stream.read_one_bit(b)) {
                    return false;
                }
                seq_scaling_list_present_flag.push_back(b);
                // todo: scaling list
                // if (seq_scaling_list_present_flag[i]) {
                //     if (i < 6) {

                //     }
                // }
            }
        }
    }

    if (!bit_stream.read_exp_golomb_ue(log2_max_frame_num_minus4)) {
        return false;
    }

    if (!bit_stream.read_exp_golomb_ue(pic_order_cnt_type)) {
        return false;
    }

    if (pic_order_cnt_type == 0) {
        if (!bit_stream.read_exp_golomb_ue(log2_max_pic_order_cnt_lsb_minus4)) {
            return false;
        } 
    } else if (pic_order_cnt_type == 1) {
        if (!bit_stream.read_one_bit(delta_pic_order_always_zero_flag)) {
            return false;
        }

        if (!bit_stream.read_exp_golomb_se(offset_for_non_ref_pic)) {
            return false;
        }

        if (!bit_stream.read_exp_golomb_se(offset_for_top_to_bottom_field)) {
            return false;
        }

        if (!bit_stream.read_exp_golomb_ue(num_ref_frames_in_pic_order_cnt_cycle)) {
            return false;
        }

        for (uint64_t i = 0; i < num_ref_frames_in_pic_order_cnt_cycle; i++) {
            int64_t v;
            if (!bit_stream.read_exp_golomb_se(v)) {
                return false;
            }
            offset_for_ref_frame.push_back(v);
        }
    }

    if (!bit_stream.read_exp_golomb_ue(max_num_ref_frames)) {
        return false;
    }

    if (!bit_stream.read_one_bit(gaps_in_frame_num_value_allowed_flag)) {
        return false;
    }

    if (!bit_stream.read_exp_golomb_ue(pic_width_in_mbs_minus1)) {
        return false;
    }

    if (!bit_stream.read_exp_golomb_ue(pic_height_in_map_units_minus1)) {
        return false;
    }

    if (!bit_stream.read_one_bit(frame_mbs_only_flag)) {
        return false;
    }

    if (!frame_mbs_only_flag) {
        if (!bit_stream.read_one_bit(mb_adaptive_frame_field_flag)) {
            return false;
        }
    }

    if (!bit_stream.read_one_bit(direct_8x8_inference_flag)) {
        return false;
    }

    if (!bit_stream.read_one_bit(frame_cropping_flag)) {
        return false;
    }

    if (frame_cropping_flag) {
        if (!bit_stream.read_exp_golomb_ue(frame_crop_left_offset)) {
            return false;
        }

        if (!bit_stream.read_exp_golomb_ue(frame_crop_right_offset)) {
            return false;
        }

        if (!bit_stream.read_exp_golomb_ue(frame_crop_top_offset)) {
            return false;
        }

        if (!bit_stream.read_exp_golomb_ue(frame_crop_bottom_offset)) {
            return false;
        }
    }

    if (!bit_stream.read_one_bit(vui_parameters_present_flag)) {
        return false;
    }

    if (vui_parameters_present_flag == 1) {
        if (!vui_parameters.parse(bit_stream)) {
            return false;
        }
    }


    return true;
}