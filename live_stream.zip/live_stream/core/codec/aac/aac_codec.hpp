#pragma once
#include <memory>
#include "../codec.hpp"
#include "mpeg4_aac.hpp"
namespace mms {
class MediaSdp;
class Payload;

class AACCodec : public Codec {
public:
    AACCodec() : Codec(CODEC_AAC, "AAC") {

    }

public:
    void set_audio_specific_config(AudioSpecificConfig & audio_specific_config) {
        audio_specific_config_ = audio_specific_config;
        ready_ = true;
    }

    AudioSpecificConfig & getAudioSpecificConfig() {
        return audio_specific_config_;
    }

    std::shared_ptr<Payload> get_payload();
private:
    AudioSpecificConfig audio_specific_config_;
};

};