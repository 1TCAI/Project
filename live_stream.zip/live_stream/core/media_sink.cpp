/*
 * @Author: jbl19860422
 * @Date: 2023-12-22 22:33:04
 * @LastEditTime: 2023-12-27 21:14:11
 * @LastEditors: jbl19860422
 * @Description: 
 * @FilePath: \mms\mms\core\media_sink.cpp
 * Copyright (c) 2023 by jbl19860422@gitee.com, All Rights Reserved. 
 */
#include <boost/asio/awaitable.hpp>
#include <boost/asio/co_spawn.hpp>
#include <boost/asio/detached.hpp>
#include <boost/asio/use_awaitable.hpp>
#include <boost/asio/redirect_error.hpp>

#include "media_sink.hpp"

#include "base/thread/thread_worker.hpp"
#include "spdlog/spdlog.h"
using namespace mms;
MediaSink::MediaSink(ThreadWorker *worker) : worker_(worker) {
    
}

MediaSink::~MediaSink() {
    spdlog::info("destroy MediaSink");
}

void MediaSink::wakeup() {

}

void MediaSink::close() {
    if (close_cb_) {
        close_cb_();
    }
}

void MediaSink::on_close(const std::function<void()> & cb) {
    close_cb_ = cb;
}

ThreadWorker *MediaSink::get_worker() {
    return worker_;
}

void MediaSink::set_source(std::shared_ptr<MediaSource> source) {
    source_ = source;
}

std::shared_ptr<MediaSource> MediaSink::get_source() {
    return source_;
}