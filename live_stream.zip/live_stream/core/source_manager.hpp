#pragma once
#include <unordered_map>
#include <mutex>
#include <memory>
#include <string>

#include <boost/serialization/singleton.hpp> 
namespace mms {
class MediaSource;
class SourceManager {
public:
    static SourceManager & get_instance() {
        return instance_;
    }

    bool add_source(const std::string & source_name, std::shared_ptr<MediaSource> source);
    void add_source_if_not_exist(const std::string & source_name, std::shared_ptr<MediaSource> source);
    bool remove_source(const std::string & source_name);
    std::shared_ptr<MediaSource> get_source(const std::string & source_name);
    std::unordered_map<std::string, std::shared_ptr<MediaSource>> get_sources();
    uint64_t get_source_count() {
        std::lock_guard<std::mutex> lck(sources_mtx_);
        return sources_.size();
    }
    void close();
private:
    static SourceManager instance_;
    std::mutex sources_mtx_;
    std::unordered_map<std::string, std::shared_ptr<MediaSource>> sources_;
};

};