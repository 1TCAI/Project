#pragma once
#include <memory>
#include <functional>

namespace mms {
class MediaSource;
class ThreadWorker;

class MediaSink : public std::enable_shared_from_this<MediaSink> {
    friend class MediaSource;
public:
    MediaSink(ThreadWorker *worker);

    void set_source(std::shared_ptr<MediaSource> source);

    std::shared_ptr<MediaSource> get_source();

    virtual ~MediaSink();

    virtual void wakeup();

    virtual void close();

    void on_close(const std::function<void()> & close_cb);

    virtual ThreadWorker *get_worker();
protected:
    std::shared_ptr<MediaSource> source_ = nullptr;
    ThreadWorker *worker_; 
    std::function<void()> close_cb_;
};

};