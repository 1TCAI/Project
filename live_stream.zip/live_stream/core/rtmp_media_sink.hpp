#pragma once
#include <vector>
#include <set>
#include <atomic>

#include <boost/asio/awaitable.hpp>

#include "media_sink.hpp"
namespace mms {
class ThreadWorker;
class RtmpMessage;

class RtmpMediaSink : public MediaSink {
public:
    RtmpMediaSink(ThreadWorker *worker);
    virtual bool init();
    virtual ~RtmpMediaSink();
    virtual bool on_audio_packet(std::shared_ptr<RtmpMessage> audio_pkt);
    virtual bool on_video_packet(std::shared_ptr<RtmpMessage> video_pkt);
    virtual boost::asio::awaitable<bool> send_rtmp_message(std::shared_ptr<RtmpMessage> pkt);
    virtual bool on_metadata(std::shared_ptr<RtmpMessage> metadata_pkt);
    virtual void wakeup();
    void on_rtmp_message(const std::function<boost::asio::awaitable<bool>(const std::vector<std::shared_ptr<RtmpMessage>> & msgs)> & cb);
    void close();
protected:
    int64_t last_send_pkt_index_ = -1;
    bool has_video_; 
    bool has_audio_;
    bool stream_ready_;
    bool working_ = false;
    std::function<boost::asio::awaitable<bool>(const std::vector<std::shared_ptr<RtmpMessage>> & msgs)> data_cb_ = {};
};
};