#include <iostream>
#include <boost/asio.hpp>
#include "base/thread/thread_pool.hpp"

#include "server/rtmp/rtmp_server.hpp"
#include "server/http/http_live_server.hpp"
#include "spdlog/spdlog.h"
using namespace mms;
int main(int argc, char *argv[]) {
    thread_pool_inst::get_mutable_instance().start(std::thread::hardware_concurrency());

    const std::string addr = "192.168.1.220";
    spdlog::info("rtmp_server.start");
    RtmpServer rtmp_server(thread_pool_inst::get_mutable_instance().get_worker(RAND_WORKER));
    if (!rtmp_server.start(addr, 1935))
    {
        spdlog::error("start rtmp server failed");
        return -1;
    }

    HttpLiveServer http_live_server(thread_pool_inst::get_mutable_instance().get_worker(RAND_WORKER));
    if (!http_live_server.start(80))
    {
        spdlog::error("start http live server failed");
        return -3;
    }

    while(1) {
        sleep(1000);
    }

    spdlog::info("stop http live server...");
    http_live_server.stop();
    spdlog::info("stop http live server done");

    spdlog::info("stop rtmp live server...");
    rtmp_server.stop();
    spdlog::info("stop rtmp live server done");

    return 0;
}