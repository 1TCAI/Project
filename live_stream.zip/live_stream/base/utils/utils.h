/*
 * @Author: jbl19860422
 * @Date: 2023-08-19 14:17:41
 * @LastEditTime: 2023-08-19 14:17:44
 * @LastEditors: jbl19860422
 * @Description: 
 * @FilePath: \mms\mms\base\utils\utils.h
 * Copyright (c) 2023 by jbl19860422@gitee.com, All Rights Reserved. 
 */
#pragma once
#include <vector>
#include <string>
#include <string_view>
#include <unordered_map>

namespace mms {
class Utils {
public:
    static bool parse_url(const std::string & url, std::string & protocol, std::string & domain, uint16_t & port, std::string & path, std::unordered_map<std::string, std::string> & params);
    static bool encode_base64( const std::string & input, std::string & output );
    static bool decode_base64( const std::string & input, std::string & output );
    static bool bin_to_hex_str(const std::string & input, std::string & output, bool upper = false);
    static bool hex_str_to_bin(const std::string & input, std::string & output);
    static uint64_t get_current_ms();
    static std::string get_bin_path();
};
};