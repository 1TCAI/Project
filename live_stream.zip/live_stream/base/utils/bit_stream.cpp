/*
 * @Author: jbl19860422
 * @Date: 2023-09-16 10:32:17
 * @LastEditTime: 2023-09-16 11:06:18
 * @LastEditors: jbl19860422
 * @Description: 
 * @FilePath: \mms\mms\base\utils\bit_stream.cpp
 * Copyright (c) 2023 by jbl19860422@gitee.com, All Rights Reserved. 
 */
