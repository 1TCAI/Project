/*
 * @Author: jbl19860422
 * @Date: 2023-08-22 07:01:05
 * @LastEditTime: 2023-08-22 07:01:20
 * @LastEditors: jbl19860422
 * @Description: 
 * @FilePath: \mms\mms\base\utils\utils.cpp
 * Copyright (c) 2023 by jbl19860422@gitee.com, All Rights Reserved. 
 */
#include <sys/time.h>
// #include <linux/time.h>

#include "utils.h"
#include "spdlog/spdlog.h"

#include <unistd.h>
#include <string.h>
#include <boost/algorithm/string.hpp>
#include <openssl/sha.h>
#include <openssl/hmac.h>
#include <openssl/md5.h>
#include <sstream>
#include <string_view>
#include <array>
#include <boost/archive/iterators/base64_from_binary.hpp>
#include <boost/archive/iterators/binary_from_base64.hpp>
#include <boost/archive/iterators/transform_width.hpp>
#include <boost/asio.hpp>
#include <filesystem>

#include <iostream>
using namespace mms;
bool Utils::parse_url(const std::string &url, std::string &protocol, std::string &domain, uint16_t &port, std::string &path, std::unordered_map<std::string, std::string> &params)
{
    // http://test.publsh.com:80/api/on_publish?sign=123456
    // https://test.publsh.com/live/app/stream.flv?sign=123456
    std::vector<std::string> vs;
    boost::split(vs, url, boost::is_any_of("?"));
    if (vs.size() <= 0)
    {
        return false;
    }

    std::vector<std::string> vs_url;
    boost::split(vs_url, vs[0], boost::is_any_of("/"));
    if (vs_url.size() <= 0)
    {
        return false;
    }
    // 获取协议名称(http/https)
    auto &tmp1 = vs_url[0];
    auto pos = tmp1.find_last_of(":");
    if (pos == std::string::npos)
    {
        return false;
    }
    protocol = tmp1.substr(0, pos);
    // 空字符
    if (vs_url.size() <= 1)
    {
        return false; //
    }
    if (vs_url[1] != "")
    {
        return false;
    }
    // 域名
    if (vs_url.size() <= 2)
    {
        return false;
    }
    auto comma_pos = vs_url[2].find_last_of(":");
    if (comma_pos == std::string::npos)
    {
        domain = vs_url[2];
        port = 80;
    }
    else
    {
        std::vector<std::string> vs_domain;
        boost::split(vs_domain, vs_url[2], boost::is_any_of(":"));
        domain = vs_domain[0];
        port = std::atoi(vs_domain[1].c_str());
    }

    // path
    if (vs_url.size() >= 4)
    { // todo：这里性能有点影响，但不大
        std::vector<std::string> vpath;
        for (size_t i = 3; i < vs_url.size(); i++)
        {
            vpath.push_back(vs_url[i]);
        }
        path = "/" + boost::join(vpath, "/");
    }
    // param
    if (vs.size() <= 1)
    {
        return true;
    }
    std::vector<std::string> vs_param;
    boost::split(vs_param, vs[1], boost::is_any_of("&"));
    if (vs_param.size() <= 0)
    {
        return true;
    }

    for (auto &p : vs_param)
    {
        std::vector<std::string> vparam;
        boost::split(vparam, p, boost::is_any_of("="));
        if (vparam.size() != 2)
        {
            return false;
        }
        params[vparam[0]] = vparam[1];
    }
    return true;
}

bool Utils::encode_base64( const std::string & input, std::string & output )
{
	typedef boost::archive::iterators::base64_from_binary<boost::archive::iterators::transform_width<std::string::const_iterator, 6, 8>> Base64EncodeIterator;
	std::stringstream result;
	try {
		std::copy( Base64EncodeIterator( input.begin() ), Base64EncodeIterator( input.end() ), std::ostream_iterator<char>( result ) );
	} catch ( ... ) {
		return false;
	}
	size_t equal_count = (3 - input.length() % 3) % 3;
	for ( size_t i = 0; i < equal_count; i++ )
	{
		result.put( '=' );
	}
	output = result.str();
	return output.empty() == false;
}
 
bool Utils::decode_base64( const std::string & input, std::string & output )
{
	typedef boost::archive::iterators::transform_width<boost::archive::iterators::binary_from_base64<std::string::const_iterator>, 8, 6> Base64DecodeIterator;
	std::stringstream result;
	try {
		std::copy( Base64DecodeIterator( input.begin() ), Base64DecodeIterator( input.end() ), std::ostream_iterator<char>( result ) );
	} catch ( ... ) {
		return false;
	}
	output = result.str();
	return output.empty() == false;
}

bool Utils::bin_to_hex_str(const std::string & input, std::string & output, bool upper) 
{
    output.resize(input.size()*2);
    for (size_t i = 0; i < input.size(); i++) {
        uint8_t d = input[i];
        uint8_t t = (d>>4)&0x0f;
        if (t < 10) {
            t += '0';
        } else {
            t += 'a' - 10;
        }
        output[i*2] = t;

        t = d&0x0f;
        if (t < 10) {
            t += '0';
        } else {
            t += (upper?'a':'A') - 10;
        }
        output[i*2+1] = t;
    }
    return true;
}

bool Utils::hex_str_to_bin(const std::string & input, std::string & output) {
    for (int i = 0; i+1 < (int)input.size(); i += 2) {
        uint8_t d = 0;
        char c0 = input[i];
        char c1 = input[i+1];
        if (c0 >= '0' && c0 <= '9') {
            d = c0 - '0';
        } else if (c0 >= 'a' && c0 <= 'f') {
            d = c0 - 'a' + 10;
        } else if (c0 >= 'A' && c0 <= 'F') {
            d = c0 - 'A' + 10;
        }

        d = d << 4;
        if (c1 >= '0' && c1 <= '9') {
            d |= c1 - '0';
        } else if (c1 >= 'a' && c1 <= 'f') {
            d |= c1 - 'a' + 10;
        } else if (c1 >= 'A' && c1 <= 'F') {
            d |= c1 - 'A' + 10;
        }
        output.append(1, (char)d);
    }
    return true;
}

uint64_t Utils::get_current_ms() {
    struct timeval tv;
    gettimeofday(&tv, NULL);
    return tv.tv_sec*1000 + tv.tv_usec/1000;
}

std::string Utils::get_bin_path() {
    char dir[4096] = {0};
    ssize_t n = readlink("/proc/self/exe", dir, 4096);
    if (n <= 0) {
        static std::string empty_str;
        return empty_str;
    }
    
    std::filesystem::path path(std::string(dir, n));
    auto p = path.remove_filename();
    return p.string();
}