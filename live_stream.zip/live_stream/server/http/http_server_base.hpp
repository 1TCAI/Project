/*
 * @Author: jbl19860422
 * @Date: 2023-09-24 09:08:29
 * @LastEditTime: 2023-10-01 21:09:07
 * @LastEditors: jbl19860422
 * @Description: 
 * @FilePath: \mms\mms\server\http\http_server_base.hpp
 * Copyright (c) 2023 by jbl19860422@gitee.com, All Rights Reserved. 
 */
#pragma once
#include <memory>
#include <functional>
#include <boost/asio/awaitable.hpp>

#include "server/tcp/tcp_server.hpp"
#include "server/http/http_conn.hpp"
#include "base/thread/thread_pool.hpp"
#include "protocol/http/http_define.h"
#include "http_server_session.hpp"
#include "router/trie_tree.hpp"
namespace mms {
class WsConn;
class HttpRequest;
class HttpResponse;

class HttpServerBase : public TcpServer<HttpConn>, public HttpRequestHandler<HttpConn> {
    using HTTP_HANDLER = std::function<boost::asio::awaitable<void>(std::shared_ptr<HttpServerSession<HttpConn>> session, 
                                                                    std::shared_ptr<HttpRequest> req, 
                                                                    std::shared_ptr<HttpResponse> resp)>;
public:
    HttpServerBase(ThreadWorker *w):TcpServer(w) {
    }
    
    virtual ~HttpServerBase();
    bool start(uint16_t port = 80);
    void stop();
protected:
    bool on_get(const std::string & path, const HTTP_HANDLER & handler);
    bool on_post(const std::string & path, const HTTP_HANDLER & handler);

    virtual bool register_route();
    // TcpServer interface
    void on_tcp_socket_open(std::shared_ptr<TcpSocket> socket) override;
    void on_tcp_socket_close(std::shared_ptr<TcpSocket> socket) override;
    // HttpServerSession interface
    boost::asio::awaitable<bool> on_new_request(std::shared_ptr<HttpServerSession<HttpConn>> session, std::shared_ptr<HttpRequest> req, std::shared_ptr<HttpResponse> resp) override;
protected:
    TrieTree<HTTP_HANDLER> get_route_tree_;
    TrieTree<HTTP_HANDLER> post_route_tree_;
    TrieTree<HTTP_HANDLER> put_route_tree_;
    TrieTree<HTTP_HANDLER> head_route_tree_;
    TrieTree<HTTP_HANDLER> delete_route_tree_;
    TrieTree<HTTP_HANDLER> options_route_tree_;
};
};