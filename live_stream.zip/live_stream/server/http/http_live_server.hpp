#pragma once
#include <memory>
#include <functional>
#include "http_server_base.hpp"
namespace mms {
class HttpLiveServer : public HttpServerBase {
public:
    HttpLiveServer(ThreadWorker *w):HttpServerBase(w) {
    }
    
    virtual ~HttpLiveServer();
private:
    bool register_route();
};
};