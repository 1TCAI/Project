/*
 * @Author: jbl19860422
 * @Date: 2023-09-16 10:32:17
 * @LastEditTime: 2023-10-02 20:14:07
 * @LastEditors: jbl19860422
 * @Description: 
 * @FilePath: \mms\mms\server\http\http_conn.hpp
 * Copyright (c) 2023 by jbl19860422@gitee.com, All Rights Reserved. 
 */
#pragma once
#include <memory>
#include <unordered_map>
#include <array>
#include <boost/asio/ip/tcp.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/array.hpp>
#include <functional>

#include "base/thread/thread_worker.hpp"
#include "base/network/tcp_socket.hpp"


namespace mms {
class HttpConn;
template<typename CONN_TYPE>
class HttpServerSession;

class HttpConn : public TcpSocket {
    friend class HttpServerSession<HttpConn>;
public:
    HttpConn(TcpSocketHandler *handler, boost::asio::ip::tcp::socket sock, ThreadWorker *worker);
    HttpConn(TcpSocketHandler *handler, ThreadWorker *worker);
    virtual ~HttpConn();
    boost::asio::awaitable<void> cycle_recv(const std::function<boost::asio::awaitable<std::pair<bool,int32_t>>(const char *buf, 
                                                                                                                int32_t len)> & recv_handler);
private:
    std::unique_ptr<char[]> buf_;
    int32_t buf_size_ = 0;
    int32_t buf_pos_ = 0;
};
};