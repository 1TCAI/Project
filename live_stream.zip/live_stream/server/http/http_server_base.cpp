/*
 * @Author: jbl19860422
 * @Date: 2023-09-16 10:32:17
 * @LastEditTime: 2023-10-02 15:44:43
 * @LastEditors: jbl19860422
 * @Description: 
 * @FilePath: \mms\mms\server\http\http_server_base.cpp
 * Copyright (c) 2023 by jbl19860422@gitee.com, All Rights Reserved. 
 */
#include "spdlog/spdlog.h"

#include <memory>
#include <fstream>
#include <boost/shared_ptr.hpp>

// #include "base/utils/utils.h"
#include "http_server_base.hpp"
#include "http_server_session.hpp"
// #include "ws_conn.hpp"

namespace mms {

bool HttpServerBase::start(uint16_t port) {
    if (!register_route()) {
        spdlog::error("http server base register router failed, port:{}", port);
        return false;
    }

    if (0 == start_listen(port)) {
        return true;
    } 
    return false;
}

HttpServerBase::~HttpServerBase() {

}

void HttpServerBase::stop() {
    stop_listen();
}

void HttpServerBase::on_tcp_socket_open(std::shared_ptr<TcpSocket> conn) {
    auto http_conn = std::static_pointer_cast<HttpConn>(conn);
    std::shared_ptr<HttpServerSession<HttpConn>> s = std::make_shared<HttpServerSession<HttpConn>>(this, http_conn);
    http_conn->set_session(s);
    s->service();
}

void HttpServerBase::on_tcp_socket_close(std::shared_ptr<TcpSocket> conn) {
    auto http_conn = std::static_pointer_cast<HttpConn>(conn);
    std::shared_ptr<HttpServerSession<HttpConn>> s = std::static_pointer_cast<HttpServerSession<HttpConn>>(http_conn->get_session());
    http_conn->clear_session();
    if (s) {
        s->close();
    }
}

bool HttpServerBase::register_route() {
    return true;
}

bool HttpServerBase::on_get(const std::string & path, const HTTP_HANDLER & handler) {
    return get_route_tree_.add_route(path, handler);
}

bool HttpServerBase::on_post(const std::string & path, const HTTP_HANDLER & handler) {
    return post_route_tree_.add_route(path, handler);
}

boost::asio::awaitable<bool> HttpServerBase::on_new_request(std::shared_ptr<HttpServerSession<HttpConn>> session,                 std::shared_ptr<HttpRequest> req, std::shared_ptr<HttpResponse> resp) {
    spdlog::debug("get new http request, path:{}", req->get_path());
    switch(req->get_method()) {
        case GET : {
            auto handler = get_route_tree_.get_route(req->get_path(), req->path_params());
            if (!handler.has_value()) {//404
                resp->add_header("Connection", "close");
                co_await resp->write_header(404, "Not Found");
                resp->close();
            } else {
                co_await handler.value()(session, req, resp);
            }
            break;
        }
        case POST : {
            auto handler = post_route_tree_.get_route(req->get_path(), req->path_params());
            if (!handler.has_value()) {//404
                resp->add_header("Connection", "close");
                co_await resp->write_header(404, "Not Found");
                resp->close();
            } else {
                co_await handler.value()(session, req, resp);
            }
            break;
        }
        default : {
            break;
        }
    }
    co_return true;
}

};