#pragma once
#include <memory>

#include "server/tcp/tcp_server.hpp"
#include "server/rtmp/rtmp_conn/rtmp_conn.hpp"
#include "base/thread/thread_pool.hpp"

namespace mms {
class RtmpServer : public TcpServer<RtmpConn> {
public:
    RtmpServer(ThreadWorker *w):TcpServer(w) {
    }
    
    bool start(const std::string & addr ,uint16_t port = 1935) {
        if (0 == start_listen(port, addr)) {
            return true;
        }
        return false;
    }

    void stop() {
        stop_listen();
    }
private:
    void on_tcp_socket_open(std::shared_ptr<TcpSocket> socket) override;
    void on_tcp_socket_close(std::shared_ptr<TcpSocket> socket) override;
};
};