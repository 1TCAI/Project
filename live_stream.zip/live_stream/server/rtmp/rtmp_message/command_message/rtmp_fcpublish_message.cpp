#include "rtmp_fcpublish_message.hpp"
#include "server/rtmp/rtmp_message/rtmp_message.hpp"
using namespace mms;
RtmpFCPublishMessage::RtmpFCPublishMessage() {

}

RtmpFCPublishMessage::RtmpFCPublishMessage(int32_t transaction_id, const std::string &stream_name) {
    command_name_.set_value("FCPublish");
    transaction_id_.set_value(transaction_id);
    stream_name_.set_value(stream_name);
}

RtmpFCPublishMessage::~RtmpFCPublishMessage() {

}

int32_t RtmpFCPublishMessage::size() const {
    int32_t size = 0;
    size += command_name_.size();
    size += transaction_id_.size();
    size += null_.size();
    size += stream_name_.size();
    return size;
}

int32_t RtmpFCPublishMessage::decode(std::shared_ptr<RtmpMessage> rtmp_msg) {
    int32_t consumed = 0;
    int32_t pos = 0;
    const uint8_t *payload = rtmp_msg->payload_;
    int32_t len = rtmp_msg->payload_size_;
    consumed = command_name_.decode(payload, len);
    if (consumed < 0) {
        return -1;
    }
    pos += consumed;
    payload += consumed;
    len -= consumed;

    consumed = transaction_id_.decode(payload, len);
    if(consumed < 0) {
        return -2;
    }
    pos += consumed;
    payload += consumed;
    len -= consumed;

    consumed = null_.decode(payload, len);
    if (consumed < 0) {
        return -3;
    }
    pos += consumed;
    payload += consumed;
    len -= consumed;

    consumed = stream_name_.decode(payload, len);
    if (consumed < 0) {
        return -4;
    }
    pos += consumed;
    payload += consumed;
    len -= consumed;
    return pos;
}

std::shared_ptr<RtmpMessage> RtmpFCPublishMessage::encode() const {
    auto need_size = size();
    std::shared_ptr<RtmpMessage> rtmp_msg = std::make_shared<RtmpMessage>(need_size);
    rtmp_msg->chunk_stream_id_ = RTMP_CHUNK_ID_COMMAND_MESSAGE;//RTMP_CHUNK_ID_PROTOCOL_CONTROL_MESSAGE;
    rtmp_msg->timestamp_ = 0;
    rtmp_msg->message_type_id_ = RTMP_MESSAGE_TYPE_AMF0_COMMAND;
    rtmp_msg->message_stream_id_ = RTMP_MESSAGE_ID_PROTOCOL_CONTROL;

    int32_t consumed = 0;
    int32_t pos = 0;
    uint8_t *payload = rtmp_msg->payload_;
    int32_t len = need_size;
    consumed = command_name_.encode(payload, len);
    if (consumed < 0) {
        return nullptr;
    }
    pos += consumed;
    payload += consumed;
    len -= consumed;

    consumed = transaction_id_.encode(payload, len);
    if(consumed < 0) {
        return nullptr;
    }
    pos += consumed;
    payload += consumed;
    len -= consumed;

    consumed = null_.encode(payload, len);
    if (consumed < 0) {
        return nullptr;
    }
    pos += consumed;
    payload += consumed;
    len -= consumed;
    
    consumed = stream_name_.encode(payload, len);
    if(consumed < 0) {
        return nullptr;
    }
    pos += consumed;
    payload += consumed;
    len -= consumed;
    rtmp_msg->payload_size_ = pos;
    return rtmp_msg;
}
