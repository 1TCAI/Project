#pragma once
#include <memory>
#include <string>

namespace mms {
class MediaBridge;
class Session;
class App;
class ThreadWorker;
class BridgeFactory {
public:
    static std::shared_ptr<MediaBridge> create_bridge(ThreadWorker *worker, 
                                                     const std::string & id, 
                                                     const std::string & domain_name, 
                                                     const std::string & app_name, 
                                                     const std::string & stream_name); 
};
};