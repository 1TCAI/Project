
#include "media_bridge.hpp"
#include "core/media_source.hpp"
#include "core/media_sink.hpp"

using namespace mms;

MediaBridge::MediaBridge(const std::string & domain_name, 
                         const std::string & app_name, 
                         const std::string & stream_name) : domain_name_(domain_name), app_name_(app_name), stream_name_(stream_name) {

}