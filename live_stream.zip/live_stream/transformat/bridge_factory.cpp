/*
 * @Author: jbl19860422
 * @Date: 2023-12-03 11:50:29
 * @LastEditTime: 2023-12-03 11:50:39
 * @LastEditors: jbl19860422
 * @Description: 
 * @FilePath: \mms\mms\server\transcode\bridge_factory.cpp
 * Copyright (c) 2023 by jbl19860422@gitee.com, All Rights Reserved. 
 */
#include "bridge_factory.hpp"
#include "base/thread/thread_worker.hpp"
#include "rtmp_to_flv.hpp"

using namespace mms;
std::shared_ptr<MediaBridge> BridgeFactory::create_bridge(ThreadWorker *worker, 
                                                         const std::string & id, 
                                                         const std::string & domain_name, 
                                                         const std::string & app_name, 
                                                         const std::string & stream_name) {
    if (id == "rtmp-flv") {
        return std::make_shared<RtmpToFlv>(worker, domain_name, app_name, stream_name);
    } 
    return nullptr;
}